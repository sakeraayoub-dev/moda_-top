# MODA TOP

موقع عرض منتجات رجالية جاهز للنشر على GitHub Pages.

## إضافة الصور
ضع صور الجاكيتات داخل مجلد `images` وسمّها:
`jacket-01.jpg` إلى `jacket-20.jpg`

إذا أردت تغيير الوصف، افتح `index.html` وابحث عن بطاقة الموديل المطلوبة.

## واتساب
الرقم مضاف مسبقاً: +963 940 545 676

## النشر
ارفع `index.html` ومجلد `images` إلى مستودع GitHub، ثم:
Settings → Pages → Deploy from a branch → main → /root
